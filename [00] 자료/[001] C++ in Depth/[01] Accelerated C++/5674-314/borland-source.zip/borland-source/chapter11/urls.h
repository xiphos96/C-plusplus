#ifndef GUARD_urls_h
#define GUARD_urls_h

#include "Vec.h"
#include <string>

Vec<std::string> find_urls(const std::string& s);

#endif

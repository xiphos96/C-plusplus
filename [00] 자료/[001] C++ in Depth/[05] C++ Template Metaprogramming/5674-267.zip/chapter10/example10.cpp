/*

    Copyright David Abrahams 2003-2004
    Copyright Aleksey Gurtovoy 2003-2004

    Distributed under the Boost Software License, Version 1.0. 
    (See accompanying file LICENSE_1_0.txt or copy at 
    http://www.boost.org/LICENSE_1_0.txt)
            
    This file was automatically extracted from the source of 
    "C++ Template Metaprogramming", by David Abrahams and 
    Aleksey Gurtovoy.

    It was built successfully with GCC 3.4.2 on Windows using
    the following command: 

        g++ -I..\..\boost_1_32_0 -c -o%TEMP%\metaprogram-chapter10-example10.o example10.cpp
        

*/


  #include <boost/array.hpp>
  struct Array
    : boost::array<boost::array<float,3>,3>
  {};

Array operator+(Array const& a, Array const& b)
{
     std::size_t const n = a.size();
     Array result;

     for (std::size_t row = 0; row != n; ++row)
         for (std::size_t col = 0; col != n; ++col)
             result[row][col] = a[row][col] + b[row][col];

     return result;
}



  Array f(Array a, Array b, Array c) 
  { 
      Array

x = a + b + c;

      return x; 
  }


#ifndef ADDRESS_H
#define ADDRESS_H

class Address {
};

#endif /* ADDRESS_H */

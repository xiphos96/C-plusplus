#ifndef DATE_H
#define DATE_H

class Date {
};

#endif /* DATE_H */

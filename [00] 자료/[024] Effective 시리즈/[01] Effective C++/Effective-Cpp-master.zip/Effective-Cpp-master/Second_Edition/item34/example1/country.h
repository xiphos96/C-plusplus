#ifndef COUNTRY_H
#define COUNTRY_H

class Country {
};

#endif /* COUNTRY_H */

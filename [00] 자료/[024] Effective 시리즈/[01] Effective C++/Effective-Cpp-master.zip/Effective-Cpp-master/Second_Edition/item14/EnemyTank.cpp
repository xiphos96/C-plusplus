#include "EnemyTank.h"

// class statics must be defined outside the class;
// initialization is to 0 by default
size_t EnemyTank::numTanks;

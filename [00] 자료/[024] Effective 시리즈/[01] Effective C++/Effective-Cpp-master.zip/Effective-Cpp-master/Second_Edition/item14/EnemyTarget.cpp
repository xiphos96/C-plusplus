#include "EnemyTarget.h"

// class statics must be defined outside the class;
// initialization is to 0 by default
size_t EnemyTarget::numTargets;

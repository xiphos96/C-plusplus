#include "EnemyTarget.h"
#include "EnemyTank.h"

int main()
{
  EnemyTarget *targetPtr = new EnemyTank;
  delete targetPtr;
}

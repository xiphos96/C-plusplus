#include "GamePlayer.h"

// The above is however a *declaration*, not a *definition*, so you must still
// define static class members in an implementation fie:
const int GamePlayer::NUM_TURNS; // mandatory definition;
                                 // goes in class impl. file

// This goes in the class header file.
class EngineeringConstants {
private:
  static const double FUDGE_FACTOR;
};

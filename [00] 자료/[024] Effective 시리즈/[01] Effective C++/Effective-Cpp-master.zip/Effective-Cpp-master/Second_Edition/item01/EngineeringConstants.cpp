#include "EngineeringConstants.h"

// This goes in the class implementation file
const double EngineeringConstants::FUDGE_FACTOR = 1.35;

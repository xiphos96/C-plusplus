int main()
{
  int a = 1;
  int b = 2;

  if ( a > b ) {
      // int temp = a;    // swap a and b
      // a = b;
      // b = temp;
  }

}

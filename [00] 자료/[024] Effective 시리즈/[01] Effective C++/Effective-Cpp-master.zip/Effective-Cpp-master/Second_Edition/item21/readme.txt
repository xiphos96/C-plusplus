With C++11, item 21 will be deprecated!

Apparently, the technique from item 21 (returning by const value) also disables
move semantics for the returned rvalue...

See also
http://www.reddit.com/r/cpp/comments/xdjr4/a_question_about_const_correctness/

// This is file example.h
inline void f() {}          // definition of f

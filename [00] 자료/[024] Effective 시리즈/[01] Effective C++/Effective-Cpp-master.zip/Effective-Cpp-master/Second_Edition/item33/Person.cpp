class Person {
public:
  int age() const { return personAge; }

private:
  int personAge;

};

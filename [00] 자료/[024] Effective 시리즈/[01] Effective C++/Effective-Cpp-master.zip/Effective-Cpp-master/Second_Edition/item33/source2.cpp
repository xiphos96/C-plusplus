// This is file source2.cpp
#include "example.h"             // also includes definition
                                 // of f

//...                              // also calls f

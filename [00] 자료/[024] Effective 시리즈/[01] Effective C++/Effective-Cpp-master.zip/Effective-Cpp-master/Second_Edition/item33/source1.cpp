// This is file source1.cpp
#include "example.h"             // includes definition of f
// contains calls to f

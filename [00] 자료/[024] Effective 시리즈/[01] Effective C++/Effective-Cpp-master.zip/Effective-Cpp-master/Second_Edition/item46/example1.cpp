class Date {
public:
  Date(int day, int month, int year);
};

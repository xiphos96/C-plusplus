const double LIB_VERSION = 1.204;

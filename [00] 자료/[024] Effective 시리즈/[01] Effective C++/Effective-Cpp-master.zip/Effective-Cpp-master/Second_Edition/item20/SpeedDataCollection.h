class SpeedDataCollection {
public:
  void addValue(int speed);       // add a new data value
 
  double averageSoFar() const;    // return average speed
};

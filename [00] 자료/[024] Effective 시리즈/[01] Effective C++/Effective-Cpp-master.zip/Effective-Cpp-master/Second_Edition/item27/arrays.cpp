int main()
{
  double values1[10];
  double values2[10];

  //values1 = values2;  // error: invalid array assignment
}

using namespace std; int getSize(){	return 200;}int main(){	const int size = 100;	const int bufferSize = getSize();	size = 200; 			const int count; 	
	return 0;}	
#include <iostream>
using namespace std; // std 네임스페이스 지정
int main()
{
	int i = 0;
	cin >> i; // 숫자 키보드 입력 받기
	cout << i; // 입력 받은 숫자를 화면에 출력하기
	return 0;
}

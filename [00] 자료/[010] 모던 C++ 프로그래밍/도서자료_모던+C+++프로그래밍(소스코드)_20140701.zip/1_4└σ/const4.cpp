int main(){	const int size = 100;	const int &size2 = size; 	int &size3 = size; 	
	return 0;}
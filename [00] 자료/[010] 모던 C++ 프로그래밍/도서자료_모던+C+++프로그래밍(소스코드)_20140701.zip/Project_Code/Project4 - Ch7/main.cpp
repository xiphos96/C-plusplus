#include "Controller.h"

int main()
{
    Controller control;
    control.runMainMenu();
    return 0;
}
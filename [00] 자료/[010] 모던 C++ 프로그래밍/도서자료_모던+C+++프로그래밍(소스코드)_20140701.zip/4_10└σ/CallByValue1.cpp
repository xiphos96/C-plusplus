#include <iostream>
using namespace std;

int main(void)
{
	int value = 3;
	int i = value;
	i = 33;

	cout << "value = " << value << endl;
	cout << "i = " << i << endl;

	return 0;
}
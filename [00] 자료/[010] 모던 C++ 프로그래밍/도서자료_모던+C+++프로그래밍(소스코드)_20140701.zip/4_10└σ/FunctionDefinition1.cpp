#include <iostream>
using namespace std;

class Chulsoo
{
public:
	void Eat();
};

int main(void)
{
	Chulsoo chulsoo;
	chulsoo.Eat();
	return 0;
}
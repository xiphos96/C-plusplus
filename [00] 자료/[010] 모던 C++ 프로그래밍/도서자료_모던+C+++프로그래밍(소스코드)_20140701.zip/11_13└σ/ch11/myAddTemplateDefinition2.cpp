template <typename T, typename U>
T const add(T const& a, U const& b)
{
    return a+b;
}


#include <iostream>

using namespace std;

int const add (int const& a, int const& b)
{
    return a + b;
}

int main()
{
    double i = 5.1:
    double j = 10.2;
 
    cout << add(i, j) << endl;
}


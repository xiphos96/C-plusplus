template <typename T>
T const add (T const& a, T const& b)
{
    return a + b;
}


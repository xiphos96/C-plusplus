#include <iostream>

using namespace std;

int const add (int const& a, int const& b)
{
    return a + b;
}

int main()
{
    int i = 5:
    int j = 10;
 
    cout << add(i, j) << endl;
}


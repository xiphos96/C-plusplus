void encryption(const unsigned char *key, 
				const unsigned char *data, 
				unsigned char *prst)
{
	prst[0] = 'a';
	prst[1] = 'b';
	prst[2] = 'c';
	prst[3] = 'd';
	prst[4] = 'e';
	prst[5] = 'f';
	prst[6] = 'g';
	prst[7] = 'h';
}
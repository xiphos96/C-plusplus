//////////////////////////////////////////////////////////////
/// 
/// \file minmax.cpp
///
/// \brief
///  �ִ� �ּҰ� ����
///
/// �˰����� min, max�� �̿��Ͽ� �ִ�, �ּ� ���� �����ϴ� ��.
///
/// \�׽�Ʈȯ��
///  Gcc3.2.2, Comeau4.3.3, VC++6.0, VC++.NET 2003
///
/// \author 
///  Kim, Seungtai( stkim@yujinrobot.com )
/// 
/// \date
///  - 2004-08-10, Kim, Seungtai, Create
/// 
/// \see
///
//////////////////////////////////////////////////////////////

#include<algorithm>
#include<vector>
#include<iostream>
#include<iterator>
#include<string>

template< typename ForwardIterator >
inline ForwardIterator minmax(ForwardIterator first, 
							  ForwardIterator last, 
							  bool min=true)
{
	if(min)
		return std::min_element( first, last );
	else
		return std::max_element( first, last );
}


int main()
{
	int a[] = { 10, 9, 3, 9, 5, 3 };
	std::vector<int> v(a, a+sizeof a/ sizeof(int));	
	std::copy( v.begin(), v.end(), std::ostream_iterator<int>(std::cout, " "));
	std::cout << std::endl;
	std::cout << "MAX: ";
	std::cout << *(minmax(v.begin(), v.end(), false)) << std::endl;
	std::cout << "MIN: ";
	std::cout << *(minmax(v.begin(), v.end())) << std::endl;
}
Mastering C++ Multithreading, by Packt

Every chapter has code files, arranged in the folder of repective chapter. 

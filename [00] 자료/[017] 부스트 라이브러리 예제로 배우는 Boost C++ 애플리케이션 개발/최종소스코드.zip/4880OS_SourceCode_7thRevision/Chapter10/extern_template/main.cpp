#include "header.hpp"

int main() {
    variant_type v1(0), v2, v3(1.1);

    (void)v1;
    (void)v2;
    (void)v3;
}


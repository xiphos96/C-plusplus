#pragma once

#define NOMINMAX

#include "targetver.h"

#include <vector>
#include <algorithm>
#include <iterator>
#include <numeric>
#include <array>
#include <iostream>
#include <amp.h>
#include <assert.h>

#include <CppUnitTest.h>

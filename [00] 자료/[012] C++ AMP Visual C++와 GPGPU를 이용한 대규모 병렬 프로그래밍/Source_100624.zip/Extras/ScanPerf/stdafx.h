#pragma once

#define NOMINMAX

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <memory>
#include <numeric>
#include <iostream>
#include <iomanip>
#include <array>

#include <amp.h>

#include "Timer.h"

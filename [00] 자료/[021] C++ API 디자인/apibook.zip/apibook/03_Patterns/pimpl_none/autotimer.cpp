///
/// \file   autotimer.cpp
/// \author Martin Reddy
/// \brief  A poor API that can be improved by Pimpl.
///
/// Copyright (c) 2010-2024, Martin Reddy. All rights reserved.
/// Distributed under the X11/MIT License. See LICENSE.txt.
/// See https://APIBook.com/ for the latest version.
///

#include "autotimer.h"

This directory contains various example programs taken from the FMOD
distribution, version 4.28. These are provided as sample illustrations
of using a flat C API, an object-oriented C++ API, and a data-driven
(or event) API.

If you wish to try running these programs, please download the FMOD
package for your platform at: http://www.fmod.org/.

All source code Copyright (c), Firelight Technologies Pty, Ltd 2004-2009.

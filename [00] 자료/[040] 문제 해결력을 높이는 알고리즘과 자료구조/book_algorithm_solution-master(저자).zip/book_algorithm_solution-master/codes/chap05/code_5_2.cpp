template<class T> void chmin(T& a, T b) {
    if (a > b) {
        a = b;
    }
}

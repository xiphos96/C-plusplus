#include <iostream>

float answer;  // the result of the divide 

int main()
{
    answer = 1/3;
    std::cout << "The value of 1/3 is " << answer << "\n"; 
    return (0);
}

/********************************************************
 * This is a mult-line comment				*
 *	T_COMMENT, T_NEWLINE				*
 ********************************************************/
const int LINE_MAX = 500;	// T_ID, T_OPERATOR, T_NUMBER

// T_L_PAREN, T_R_PAREN
static void do_file( const char *const name)
{
    // T_L_CURLY
    char *name = "Test"		// T_STRING

    // T_R_CURLY
}
// T_EOF


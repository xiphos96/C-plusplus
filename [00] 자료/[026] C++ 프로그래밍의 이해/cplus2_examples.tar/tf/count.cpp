/* number of times through the loop */
int counter = 0;

/* trivial example */
void inc_counter()
{
    ++counter;
}

#include <iostream>

int term;	// term used in two expressions
int main()
{

    term = 3 * 5;
    std::cout << "Twice " << term << " is " << 2*term << "\n";
    std::cout << "Three times " << term << " is " << 3*term << "\n";
    return (0);
}

#include <cstdio>
int main()
{
    int answer;   

    answer = 2 + 2;

    std::printf("The answer is %d\n");
    return (0);
}

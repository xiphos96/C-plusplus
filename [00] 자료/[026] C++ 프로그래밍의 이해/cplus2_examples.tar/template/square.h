template<class number> extern number square(const number value);

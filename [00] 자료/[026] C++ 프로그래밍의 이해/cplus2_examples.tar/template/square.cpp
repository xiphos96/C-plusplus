#include "square.h"

export 
template<class number> number square(const number i)
{
    return (i.value * i.value);
}

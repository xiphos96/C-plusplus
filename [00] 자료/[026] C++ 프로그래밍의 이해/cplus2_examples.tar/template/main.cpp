#include "square.h"
#include "integer.h"

int main()
{
    integer test(5);

    integer test2 = square(test);
    return (0);
}


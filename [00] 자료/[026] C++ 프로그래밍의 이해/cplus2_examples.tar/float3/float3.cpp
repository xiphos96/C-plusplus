#include <cstdio>

int main()
{
    float result;

    result = 21.0 / 7.0;
    std::printf("The result is %d\n", result);
    return (0);
}

int   integer;	// an integer
float floating;	// a floating point number

int main()
{
    floating = 1.0 / 2.0; 	  // assign "floating" 0.5

    integer = 1 / 3; 		  // assign integer 0

    floating = (1 / 2) + (1 / 2); // assign floating 0.0

    floating = 3.0 / 2.0; 	  // assign floating 1.5

    integer = floating;	  	  // assign integer 1

    return (0);
}

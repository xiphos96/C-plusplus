  

# 모던 C++로 배우는 동시성 프로그래밍
![모던 C++로 배우는 동시성 프로그래밍](http://image.kyobobook.co.kr/images/book/xlarge/309/x9791188621309.jpg)


**출판사** 제이펍  
**원서명** Concurrency with Modern C++   
(원서 ISBN: 없음)  
**저자명** 라이너 그림  
**역자명** 배장열  
**출판일** 2018년 8월 6일  
**페이지** 316쪽  
**ISBN**  979-11-88621-30-9(93000)  



[### 도서 소개 페이지 바로 가기 ###](http://jpub.tistory.com/826)
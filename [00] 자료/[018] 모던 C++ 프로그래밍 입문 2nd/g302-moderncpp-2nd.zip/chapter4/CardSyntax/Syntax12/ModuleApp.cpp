import mymodule;
#include <iostream>

int main()
{
	std::cout << "f() returns " << f() << std::endl;
	// std::cout << "f_private() returns " << f_private() << std::endl;

	return 0;
}
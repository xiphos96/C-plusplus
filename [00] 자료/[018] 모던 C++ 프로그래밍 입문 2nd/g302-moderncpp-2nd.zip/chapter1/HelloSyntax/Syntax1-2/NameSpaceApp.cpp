#include <iostream>
using std::cout;
using std::endl;

int main()
{
	cout << "hello world!" << endl;

	return 0;
}
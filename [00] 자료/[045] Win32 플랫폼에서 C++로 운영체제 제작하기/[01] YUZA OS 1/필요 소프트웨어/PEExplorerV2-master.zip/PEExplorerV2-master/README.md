# PEExplorerV2
Portable Executable Explorer version 2

![Screenshot](https://github.com/zodiacon/PEExplorerV2/blob/master/PEExplorerV2.png)

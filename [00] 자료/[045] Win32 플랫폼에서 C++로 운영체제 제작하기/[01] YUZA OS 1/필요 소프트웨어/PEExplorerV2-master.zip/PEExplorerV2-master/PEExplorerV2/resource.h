//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PEExplorerV2.rc
//
#define IDD_ABOUTBOX                    100
#define ID_FILE_EXPORT                  101
#define IDR_MAINFRAME                   128
#define IDS_COPYRIGHT                   129
#define IDI_CLOSE                       202
#define IDI_COPY                        203
#define IDI_EXPORTS                     204
#define IDI_IMPORTS                     205
#define IDI_SECTIONS                    206
#define IDI_DLL                         207
#define IDI_INFO                        208
#define IDI_EXPORT                      209
#define IDI_IMPORT                      210
#define IDI_OPEN                        211
#define IDI_PIN                         212
#define IDI_RESOURCES                   213
#define IDI_FOLDER_CLOSED               214
#define IDI_FOLDER_OPEN                 215
#define IDI_DIRS                        216
#define IDI_FILE_DLL                    217
#define IDI_FILE_EXE                    218
#define IDI_FORWARD                     219
#define IDI_LIBRARY_IMPORT              220
#define IDI_APISET_LIB                  221
#define IDR_MENU1                       222
#define IDR_CONTEXT                     222
#define IDI_NUM1                        223
#define IDI_NUM2                        224
#define IDI_NUM4                        225
#define IDI_NUM8                        226
#define IDI_SAVE                        227
#define IDI_ASM                         228
#define IDI_HEADERS                     229
#define IDI_STRUCT                      230
#define IDI_ICON1                       231
#define IDI_VIEW                        231
#define IDI_ICON2                       232
#define IDI_COMPONENT                   232
#define IDI_CLASS                       233
#define IDI_DELEGATE                    234
#define IDI_ENUM                        235
#define IDI_EVENT                       236
#define IDI_INTERFACE                   237
#define IDI_ATTRIBUTE                   238
#define IDI_NEWWINDOW                   239
#define IDI_CLOSEALL                    240
#define IDI_DELETE                      241
#define IDI_METHOD                      242
#define IDI_PROPERTY                    243
#define IDI_FIELD                       244
#define IDI_CCTOR                       245
#define IDI_CTOR                        246
#define IDC_SYSLINK1                    1000
#define IDC_LINK                        1000
#define ID_VIEW_TREEPANE                32774
#define ID_OPTIONS_ALWAYSONTOP          32775
#define ID_VIEW_SUMMARY                 32777
#define ID_VIEW_SECTIONS                32778
#define ID_VIEW_DIRECTORIES             32779
#define ID_VIEW_EXPORTS                 32780
#define ID_VIEW_IMPORTS                 32781
#define ID_VIEW_RESOURCES               32782
#define ID_VIEW_DOTNET                  32783
#define ID_WINDOW_CLOSE                 32784
#define ID_WINDOW_CLOSEALL              32785
#define ID_FILE_RECENTFILES             32786
#define ID_EDIT_FILTER                  32800
#define ID_FILE_OPENINANEWWINDOW        32801
#define ID_OBJECT_VIEWDATA              32802
#define ID_WINDOW_NEWWINDOW             32803
#define ID_IMPORTLIB_OPENINNEWWINDOW    32804
#define ID_TYPE_VIEWMEMBERS             32805

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        247
#define _APS_NEXT_COMMAND_VALUE         32806
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
